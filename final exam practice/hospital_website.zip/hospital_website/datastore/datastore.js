/**
 * datastore.js
 * 
 * @author 
 * @since 
 */
 "use strict";

 const dataStore = (function(){
     const patientData = [
         {patientId: "EP-111-000123", firstName: "Dinesh", middleName: "K", lastName: "Sarma", dob: "1994-09-21", department:"Cardiology", outPatient:"Yes"}
     ];
 
     const getData = function() {
         return patientData;
     }

     const saveData = function(newPatient) {
        patientData.push(newPatient);
     }
 
 
     return {
         getData: getData,
         saveData: saveData
     }
 
 })();
 
 module.exports = dataStore;