/**
 * student.js
 */
"use strict";

function Student(studentId, fullName, levelOfStudy) {
    this.studentId = studentId;
    this.fullName = fullName;
    this.levelOfStudy = levelOfStudy;
}

module.exports = Student;

