exports.add = function (req,res,vals) {
    switch(vals.calculator) {
        case "add":
            var result = parseInt(vals.first) + parseInt(vals.second);
          break;
        case "mult":
            var result = parseInt(vals.first) * parseInt(vals.second);
          break;
          case "divi":
            var result = parseInt(vals.first) / parseInt(vals.second);
          break;
        case "subs":
            var result = parseInt(vals.first) - parseInt(vals.second);
          break;
        default:
          var result="wrong input"
      }
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write("<!DOCTYPE html>");
    res.write("<html>");
    res.write("<head><meta charset=\"utf-8\"/>");
    res.write("<title>Calculator Web Site</title>");
    res.write("</head>");
    res.write("<body>");
    res.write("<p>The sum is: ");
    res.write(String(result));
    res.write("</p>");
    res.write("<a href='http://localhost:8080/SimpleAdder.html'>");
    res.write("Back to operations");
    res.write("</a>");
    res.write("</body>");
    res.write("</html>");
    return res.end();
};


// exports.add = function (req,res,vals) {
//     var sum = parseInt(vals.first) + parseInt(vals.second);
//         res.writeHead(200, {'Content-Type': 'text/html'});
//         res.write(`<!DOCTYPE html>
//           <html>
//            <head><meta charset=\"utf-8\"/>
//             <title>Calculator Web Site</title>
//            </head>
//            <body>
//              <p>The sum is:  ${String(sum)}</p>
//            </body>
//           </html> ` );    
//           return res.end();
//     };
    

    